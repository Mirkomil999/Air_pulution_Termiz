Total prediction rows: 4284
Duplicate target dates within model/horizon: 0
Date-origin-lead inconsistencies: 0
Common target dates across all horizons: 98
Common (date, lead) pairs across all horizons: 98
Different horizons have different date coverage and forecast-lead composition.
Bootstrap uses forecast origins as units; origins may be temporally dependent.
sMAPE and MAPE are different metrics and cannot be directly compared.
If ablation_metadata lists only univariate channels, do not claim multivariate experiments.
This script analyzes archived predictions; it does not independently verify training leakage or dataset provenance.